# شاد شاد — بسته اصلاح‌شده Cloudflare Pages

این بسته مخصوص **Cloudflare Pages با اتصال GitHub** است، نه Cloudflare Worker upload و نه دستور `wrangler deploy`.

## تنظیمات Build در Cloudflare Pages
- Framework preset: None
- Build command: خالی (هیچ دستوری وارد نکن)
- Build output directory: `public`
- Root directory: خالی یا `/`

## نکته مهم درباره خطای قبلی
اگر در گزارش Deploy هنوز عبارت `Executing user deploy command: npx wrangler deploy` دیده می‌شود، این دستور از تنظیمات پروژه در داشبورد Cloudflare آمده است، نه از فایل‌های این بسته.
در Pages > Settings > Builds & deployments، فیلد Deploy command را پاک کن (اگر نمایش داده می‌شود) و Build command را هم خالی بگذار. سپس Save و Retry deployment را بزن.

## ساختار
- `public/`: سایت و صفحه بررسی Backend
- `functions/`: Cloudflare Pages Functions؛ در ریشه مخزن بماند، داخل public نبر.
- `migrations/0001_initial.sql`: ساخت جداول D1

## D1
1. یک D1 Database بساز.
2. در Pages > Settings > Functions > D1 database bindings یک binding با نام `DB` به دیتابیس وصل کن.
3. migration فایل `migrations/0001_initial.sql` را در D1 Console اجرا کن.
4. در Pages > Settings > Environment variables، Secret با نام `BOOTSTRAP_TOKEN` تنظیم کن.
5. بعد از deploy، `/api/health` را آزمایش کن؛ سپس `/backend-status.html` را باز کن و مدیر اولیه را بساز.
6. پس از ساخت مدیر، Secret راه‌اندازی را حذف کن.

## هشدار مهم
این نسخه زیرساخت پایه API را دارد، اما رابط اصلی هنوز به طور کامل از localStorage به D1 منتقل نشده است. قبل از تکمیل اتصال فرم‌ها، مجوزهای دقیق والدین و کارکنان، آزمون امنیتی و پشتیبان‌گیری، اطلاعات واقعی و حساس کودکان را وارد نکن.
