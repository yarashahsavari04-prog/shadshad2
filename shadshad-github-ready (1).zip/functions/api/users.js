import { json, requireSession, audit, originAllowed, randomToken, passwordHash } from "../_lib/auth.js";
const ROLES=new Set(["admin","manager","teacher","accountant","health","reception"]);
export async function onRequestGet({request,env}) {
 const a=await requireSession(request,env);if(a.response)return a.response;
 if(a.session.role!=="admin")return json({error:"فقط مدیر کل می‌تواند فهرست کاربران را ببیند."},403);
 const rows=await env.DB.prepare("SELECT id,name,email,role,branch_id,status,created_at FROM users WHERE tenant_id=? ORDER BY created_at DESC").bind(a.session.tenant_id).all();
 return json({ok:true,users:rows.results});
}
export async function onRequestPost({request,env}) {
 if(!originAllowed(request))return json({error:"درخواست نامعتبر است."},403);
 const a=await requireSession(request,env);if(a.response)return a.response;
 if(a.session.role!=="admin")return json({error:"فقط مدیر کل می‌تواند کاربر بسازد."},403);
 let b;try{b=await request.json()}catch{return json({error:"JSON نامعتبر است."},400)}
 const name=String(b.name||"").trim(),email=String(b.email||"").trim().toLowerCase(),password=String(b.password||""),role=String(b.role||"");
 const branchId=b.branchId?String(b.branchId):null;
 if(name.length<2||name.length>100||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||password.length<12||password.length>200||!ROLES.has(role))return json({error:"نام، ایمیل، رمز حداقل ۱۲ نویسه‌ای یا نقش معتبر نیست."},400);
 if(role!=="admin"&&!branchId)return json({error:"برای کاربران غیرمدیر، شعبه الزامی است."},400);
 if(branchId){const branch=await env.DB.prepare("SELECT id FROM branches WHERE id=? AND tenant_id=? AND status='active'").bind(branchId,a.session.tenant_id).first();if(!branch)return json({error:"شعبه معتبر نیست."},400)}
 const salt=randomToken(16),digest=await passwordHash(password,salt),id=crypto.randomUUID();
 try{await env.DB.prepare(`INSERT INTO users(id,tenant_id,branch_id,name,email,password_salt,password_hash,role,status,created_at)
 VALUES(?,?,?,?,?,?,?,?,'active',datetime('now'))`).bind(id,a.session.tenant_id,branchId,name,email,salt,digest,role).run()}
 catch{return json({error:"این ایمیل قبلاً ثبت شده یا داده تکراری است."},409)}
 await audit(env,a.session,"create","users",id,{email,role,branchId});
 return json({ok:true,user:{id,name,email,role,branchId}},201);
}
