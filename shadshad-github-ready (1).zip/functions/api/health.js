import { json } from "../_lib/auth.js";
export async function onRequestGet({ env }) {
  try {
    await env.DB.prepare("SELECT 1 AS ok").first();
    return json({ ok: true, service: "shadshad-api", database: "connected", version: 1 });
  } catch (error) {
    return json({ ok: false, service: "shadshad-api", database: "unavailable", error: "D1 connection failed" }, 503);
  }
}
