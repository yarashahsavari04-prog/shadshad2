import { json, getSession } from "../../_lib/auth.js";
export async function onRequestGet({ request, env }) {
  const s=await getSession(request,env);
  if(!s)return json({authenticated:false},401);
  return json({authenticated:true,user:{id:s.user_id,name:s.name,email:s.email,role:s.role,branchId:s.branch_id,tenantId:s.tenant_id}});
}
