import { json, passwordHash, randomToken, hashText, secureCookie, originAllowed } from "../../_lib/auth.js";
export async function onRequestPost({ request, env }) {
  if (!originAllowed(request)) return json({ error: "درخواست نامعتبر است." }, 403);
  let body; try { body = await request.json(); } catch { return json({ error: "داده ارسالی معتبر نیست." },400); }
  const email=String(body.email||"").trim().toLowerCase(), password=String(body.password||"");
  if(email.length>254||password.length>200) return json({error:"اطلاعات ورود نامعتبر است."},400);
  const recent=await env.DB.prepare("SELECT COUNT(*) AS n FROM login_attempts WHERE email=? AND attempted_at>datetime('now','-15 minutes')").bind(email).first();
  if((recent?.n||0)>=10)return json({error:"تلاش‌های ورود زیاد بوده است؛ ۱۵ دقیقه دیگر دوباره امتحان کن."},429);
  const user=await env.DB.prepare("SELECT * FROM users WHERE email=? AND status=? LIMIT 1").bind(email,"active").first();
  // Keep timing work for unknown emails to reduce account enumeration timing differences.
  const salt=user?.password_salt || "shadshad-invalid-user-salt";
  const calculated=await passwordHash(password,salt);
  if(!user||calculated!==user.password_hash) {
    const ip=request.headers.get("cf-connecting-ip")||"unknown",ipHash=await hashText(ip);
    await env.DB.prepare("INSERT INTO login_attempts(id,email,ip_hash,attempted_at) VALUES(?,?,?,datetime('now'))").bind(crypto.randomUUID(),email,ipHash).run();
    return json({error:"ایمیل یا رمز عبور صحیح نیست."},401);
  }
  await env.DB.prepare("DELETE FROM login_attempts WHERE email=?").bind(email).run();
  const token=randomToken(),tokenHash=await hashText(token),id=crypto.randomUUID();
  await env.DB.prepare(`INSERT INTO sessions(id,tenant_id,user_id,token_hash,expires_at,created_at)
    VALUES(?,?,?, ?,datetime('now','+12 hours'),datetime('now'))`).bind(id,user.tenant_id,user.id,tokenHash).run();
  return json({ok:true,user:{id:user.id,name:user.name,email:user.email,role:user.role,branchId:user.branch_id}},200,{"set-cookie":secureCookie(token,43200)});
}
