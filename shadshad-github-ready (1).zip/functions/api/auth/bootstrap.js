import { json, randomToken, passwordHash, secureCookie, hashText, originAllowed, audit } from "../../_lib/auth.js";
export async function onRequestPost({ request, env }) {
  if (!originAllowed(request)) return json({ error: "درخواست نامعتبر است." }, 403);
  if (!env.BOOTSTRAP_TOKEN) return json({ error: "راه‌اندازی اولیه هنوز در تنظیمات سرور فعال نشده است." }, 503);
  if (request.headers.get("x-bootstrap-token") !== env.BOOTSTRAP_TOKEN) return json({ error: "توکن راه‌اندازی نادرست است." }, 403);
  let body; try { body = await request.json(); } catch { return json({ error: "داده ارسالی معتبر نیست." }, 400); }
  const name = String(body.name || "").trim(), email = String(body.email || "").trim().toLowerCase(), password = String(body.password || "");
  if (name.length < 2 || name.length > 100 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 12 || password.length > 200)
    return json({ error: "نام، ایمیل معتبر و رمز حداقل ۱۲ نویسه‌ای لازم است." }, 400);
  const count = await env.DB.prepare("SELECT COUNT(*) AS n FROM users").first();
  if (count.n > 0) return json({ error: "مدیر اولیه قبلاً ساخته شده است؛ راه‌اندازی مجدد بسته است." }, 409);
  const tenantId = crypto.randomUUID(), userId = crypto.randomUUID(), salt = randomToken(16), digest = await passwordHash(password, salt);
  await env.DB.prepare("INSERT INTO tenants(id,name,created_at) VALUES(?,?,datetime('now'))").bind(tenantId, "شاد شاد").run();
  await env.DB.prepare(`INSERT INTO users(id,tenant_id,name,email,password_salt,password_hash,role,status,created_at)
    VALUES(?,?,?,?,?,?,'admin','active',datetime('now'))`).bind(userId, tenantId, name, email, salt, digest).run();
  const token = randomToken(), tokenHash = await hashText(token), sessionId = crypto.randomUUID();
  await env.DB.prepare(`INSERT INTO sessions(id,tenant_id,user_id,token_hash,expires_at,created_at)
    VALUES(?,?,?, ?,datetime('now','+12 hours'),datetime('now'))`).bind(sessionId,tenantId,userId,tokenHash).run();
  await audit(env,{tenant_id:tenantId,user_id:userId,branch_id:null},"bootstrap","auth",userId,{email});
  return json({ ok:true, user:{id:userId,name,email,role:"admin"}, message:"مدیر اولیه ایجاد شد." },201,{"set-cookie":secureCookie(token,43200)});
}
