import { json, cookieValue, hashText, clearCookie, originAllowed } from "../../_lib/auth.js";
export async function onRequestPost({ request, env }) {
  if (!originAllowed(request)) return json({ error: "درخواست نامعتبر است." },403);
  const raw=cookieValue(request,"shadshad_session");
  if(raw) await env.DB.prepare("DELETE FROM sessions WHERE token_hash=?").bind(await hashText(raw)).run();
  return json({ok:true},200,{"set-cookie":clearCookie()});
}
