import { json, requireSession, audit, originAllowed } from "../_lib/auth.js";
export async function onRequestGet({request,env}) {
 const a=await requireSession(request,env);if(a.response)return a.response;
 const rows=await env.DB.prepare("SELECT id,name,code,address,capacity,status,created_at FROM branches WHERE tenant_id=? ORDER BY name").bind(a.session.tenant_id).all();
 return json({ok:true,branches:rows.results});
}
export async function onRequestPost({request,env}) {
 if(!originAllowed(request))return json({error:"درخواست نامعتبر است."},403);
 const a=await requireSession(request,env);if(a.response)return a.response;
 if(a.session.role!=="admin")return json({error:"فقط مدیر کل می‌تواند شعبه بسازد."},403);
 let b;try{b=await request.json()}catch{return json({error:"JSON نامعتبر است."},400)}
 const name=String(b.name||"").trim(),code=String(b.code||"").trim(),capacity=Number(b.capacity)||0;
 if(name.length<2||name.length>120||capacity<0||capacity>10000)return json({error:"نام یا ظرفیت نامعتبر است."},400);
 const id=crypto.randomUUID();
 await env.DB.prepare("INSERT INTO branches(id,tenant_id,name,code,address,capacity,status,created_at) VALUES(?,?,?,?,?,?,'active',datetime('now'))")
 .bind(id,a.session.tenant_id,name,code,String(b.address||"").slice(0,500),capacity).run();
 await audit(env,a.session,"create","branches",id,{name,code});
 return json({ok:true,id},201);
}
