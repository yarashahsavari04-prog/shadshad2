import { json, requireSession, canAccess, audit, originAllowed } from "../../_lib/auth.js";
const MODULES=new Set(["children","families","classes","attendance","journal","incidents","media","consents","finance","staff","inventory","calendar","messages","transport","nutrition","health","development","maintenance","documents","reports","branches","enrollment","loyalty","familyServices"]);
const MAX_BODY=256*1024;
export async function onRequestGet({request,env,params}) {
  const auth=await requireSession(request,env);if(auth.response)return auth.response;
  const s=auth.session,moduleName=String(params.module||"");
  if(!MODULES.has(moduleName)||!canAccess(s,moduleName))return json({error:"به این بخش دسترسی نداری."},403);
  const url=new URL(request.url),branch=url.searchParams.get("branchId");
  let rows;
  if(s.role==="admin" && branch){
    rows=await env.DB.prepare(`SELECT id,branch_id,payload_json,version,updated_at FROM app_records WHERE tenant_id=? AND module=? AND branch_id=? ORDER BY updated_at DESC LIMIT 500`).bind(s.tenant_id,moduleName,branch).all();
  } else if(s.role==="admin"){
    rows=await env.DB.prepare(`SELECT id,branch_id,payload_json,version,updated_at FROM app_records WHERE tenant_id=? AND module=? ORDER BY updated_at DESC LIMIT 500`).bind(s.tenant_id,moduleName).all();
  } else {
    if(!s.branch_id)return json({error:"برای این حساب شعبه مشخص نشده است."},403);
    rows=await env.DB.prepare(`SELECT id,branch_id,payload_json,version,updated_at FROM app_records WHERE tenant_id=? AND module=? AND branch_id=? ORDER BY updated_at DESC LIMIT 500`).bind(s.tenant_id,moduleName,s.branch_id).all();
  }
  return json({ok:true,module:moduleName,records:rows.results.map(r=>({id:r.id,branchId:r.branch_id,version:r.version,updatedAt:r.updated_at,data:JSON.parse(r.payload_json)}))});
}
export async function onRequestPost({request,env,params}) {
  if(!originAllowed(request))return json({error:"درخواست نامعتبر است."},403);
  const auth=await requireSession(request,env);if(auth.response)return auth.response;
  const s=auth.session,moduleName=String(params.module||"");
  if(!MODULES.has(moduleName)||!canAccess(s,moduleName,true))return json({error:"به این بخش دسترسی نوشتن نداری."},403);
  const raw=await request.text();if(raw.length>MAX_BODY)return json({error:"حجم داده بیش از حد مجاز است."},413);
  let body;try{body=JSON.parse(raw)}catch{return json({error:"JSON نامعتبر است."},400)}
  const id=String(body.id||"").trim(),data=body.data;
  if(!/^[A-Za-z0-9_-]{1,100}$/.test(id)||!data||typeof data!=="object"||Array.isArray(data))return json({error:"شناسه یا داده رکورد معتبر نیست."},400);
  let branchId=s.branch_id;
  if(s.role==="admin" && body.branchId){
    const b=await env.DB.prepare("SELECT id FROM branches WHERE id=? AND tenant_id=? AND status='active'").bind(body.branchId,s.tenant_id).first();
    if(!b)return json({error:"شعبه انتخاب‌شده معتبر نیست."},400);branchId=b.id;
  }
  if(!branchId)return json({error:"ابتدا شعبه را برای این کاربر تعیین کن."},400);
  const existing=await env.DB.prepare("SELECT id,version FROM app_records WHERE id=? AND tenant_id=? AND module=? AND branch_id=?").bind(id,s.tenant_id,moduleName,branchId).first();
  const expected=Number(body.version||0);
  if(existing && expected && expected!==existing.version)return json({error:"این رکورد در دستگاه/نشست دیگری تغییر کرده؛ داده را تازه‌سازی و دوباره تلاش کن."},409);
  const nextVersion=(existing?.version||0)+1;
  await env.DB.prepare(`INSERT INTO app_records(id,tenant_id,branch_id,module,payload_json,version,created_by,updated_by,created_at,updated_at)
    VALUES(?,?,?,?,?,?,?,?,datetime('now'),datetime('now'))
    ON CONFLICT(id) DO UPDATE SET payload_json=excluded.payload_json,version=excluded.version,updated_by=excluded.updated_by,updated_at=datetime('now')
    WHERE app_records.tenant_id=excluded.tenant_id AND app_records.module=excluded.module AND app_records.branch_id=excluded.branch_id`)
    .bind(id,s.tenant_id,branchId,moduleName,JSON.stringify(data),nextVersion,s.user_id,s.user_id).run();
  await audit(env,s,existing?"update":"create",moduleName,id,{version:nextVersion});
  return json({ok:true,id,branchId,version:nextVersion});
}
export async function onRequestDelete({request,env,params}) {
  if(!originAllowed(request))return json({error:"درخواست نامعتبر است."},403);
  const auth=await requireSession(request,env);if(auth.response)return auth.response;
  const s=auth.session,moduleName=String(params.module||"");
  if(!MODULES.has(moduleName)||!canAccess(s,moduleName,true))return json({error:"به این بخش دسترسی نداری."},403);
  const id=new URL(request.url).searchParams.get("id");if(!id)return json({error:"شناسه رکورد الزامی است."},400);
  let result;
  if(s.role==="admin")result=await env.DB.prepare("DELETE FROM app_records WHERE id=? AND tenant_id=? AND module=?").bind(id,s.tenant_id,moduleName).run();
  else if(s.branch_id)result=await env.DB.prepare("DELETE FROM app_records WHERE id=? AND tenant_id=? AND module=? AND branch_id=?").bind(id,s.tenant_id,moduleName,s.branch_id).run();
  else return json({error:"دسترسی شعبه تعریف نشده است."},403);
  if(result.meta.changes)await audit(env,s,"delete",moduleName,id,{});
  return json({ok:true,deleted:result.meta.changes});
}
