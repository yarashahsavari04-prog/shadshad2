const encoder = new TextEncoder();
export const json = (data, status = 200, extra = {}) => new Response(JSON.stringify(data), {
  status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...extra }
});
export async function hashText(value) {
  const digest = await crypto.subtle.digest("SHA-256", encoder.encode(value));
  return [...new Uint8Array(digest)].map(x => x.toString(16).padStart(2, "0")).join("");
}
export function randomToken(bytes = 32) {
  const a = crypto.getRandomValues(new Uint8Array(bytes));
  return btoa(String.fromCharCode(...a)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
export async function passwordHash(password, salt) {
  const key = await crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: encoder.encode(salt), iterations: 210000 }, key, 256);
  return [...new Uint8Array(bits)].map(x => x.toString(16).padStart(2, "0")).join("");
}
export function cookieValue(request, name) {
  const raw = request.headers.get("cookie") || "";
  const part = raw.split(";").map(x => x.trim()).find(x => x.startsWith(name + "="));
  return part ? decodeURIComponent(part.slice(name.length + 1)) : "";
}
export function secureCookie(token, maxAge) {
  return `shadshad_session=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${maxAge}`;
}
export function clearCookie() {
  return "shadshad_session=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0";
}
export function originAllowed(request) {
  const origin = request.headers.get("origin");
  if (!origin) return true;
  try { return new URL(origin).host === new URL(request.url).host; } catch { return false; }
}
export async function getSession(request, env) {
  const raw = cookieValue(request, "shadshad_session");
  if (!raw) return null;
  const tokenHash = await hashText(raw);
  const row = await env.DB.prepare(`
    SELECT s.id AS session_id, s.user_id, s.tenant_id, s.expires_at,
           u.name, u.email, u.role, u.branch_id, u.status
    FROM sessions s JOIN users u ON u.id=s.user_id
    WHERE s.token_hash=? AND s.expires_at > datetime('now') AND u.status='active'
  `).bind(tokenHash).first();
  return row || null;
}
export async function requireSession(request, env) {
  const session = await getSession(request, env);
  if (!session) return { response: json({ error: "برای ادامه وارد حساب کاربری شو." }, 401) };
  return { session };
}
export async function audit(env, session, action, moduleName, recordId, detail = {}) {
  await env.DB.prepare(`INSERT INTO audit_logs
    (id,tenant_id,user_id,branch_id,action,module,record_id,detail_json,created_at)
    VALUES(?,?,?,?,?,?,?,?,datetime('now'))`)
    .bind(crypto.randomUUID(), session.tenant_id, session.user_id, session.branch_id || null,
      action, moduleName || null, recordId || null, JSON.stringify(detail)).run();
}
export function canAccess(session, moduleName, write = false) {
  const permissions = {
    admin: ["*"],
    manager: ["children","families","classes","attendance","journal","incidents","media","consents","finance","staff","inventory","calendar","messages","transport","nutrition","health","development","maintenance","documents","reports","branches","enrollment","loyalty","familyServices"],
    teacher: ["children","classes","attendance","journal","incidents","media","nutrition","development","transport"],
    accountant: ["finance","reports","enrollment"],
    health: ["health","nutrition","incidents"],
    reception: ["children","families","attendance","calendar","messages","enrollment","familyServices"]
  };
  const allowed = permissions[session.role] || [];
  return allowed.includes("*") || allowed.includes(moduleName);
}
