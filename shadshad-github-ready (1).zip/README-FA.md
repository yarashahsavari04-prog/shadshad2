# شاد شاد — نسخه آماده GitHub و Cloudflare Pages

## ساختار
- `public/`: فایل‌های سایت
- `functions/`: API های Cloudflare Pages Functions
- `migrations/`: ساختار پایگاه داده D1
- `wrangler.toml`: تنظیمات D1

## تنظیم Cloudflare Pages
در Cloudflare از Workers & Pages گزینه Create application > Pages > Connect to Git را انتخاب و این مخزن را متصل کنید.

Build settings:
- Framework preset: None
- Build command: خالی (بدون build)
- Build output directory: `public`
- Root directory: `/`

فایل‌های `functions/` و `wrangler.toml` باید در ریشه مخزن باقی بمانند.

## راه‌اندازی D1
1. در Cloudflare یک D1 database با نام `shadshad-db` بسازید.
2. مقدار `database_id` در `wrangler.toml` را با شناسه واقعی D1 جایگزین کنید.
3. migration فایل `migrations/0001_initial.sql` را روی دیتابیس Remote اجرا کنید.
4. در تنظیمات Pages یک secret با نام `BOOTSTRAP_TOKEN` اضافه کنید.
5. پس از Deploy، `/api/health` را آزمایش کنید و سپس `/backend-status.html` را برای ساخت مدیر اولیه باز کنید.
6. بعد از ساخت مدیر اولیه، Secret راه‌اندازی را حذف یا غیرفعال کنید.

## مهم
این مخزن شامل زیرساخت پایه API و دیتابیس است؛ رابط اصلی `public/index.html` هنوز به‌طور کامل از localStorage به API/D1 منتقل نشده است. بنابراین تا تکمیل اتصال فرم‌ها، مجوزهای دقیق، آزمون امنیتی و پشتیبان‌گیری، اطلاعات واقعی و حساس کودکان را وارد نکنید.
